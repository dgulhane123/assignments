package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CalculatorPage {

    WebDriver driver;
    public CalculatorPage(WebDriver driver1)
    {
        driver=driver1;
        driver.get("https://www.calculator.net/bmi-calculator.html");
        driver.manage().window().maximize();
    }
     public void resetCalculator()
    {
       driver.findElement(By.className("clearbtn")).click();
    }
    public void enterAge(String a1)
    {
        driver.findElement(By.id("cage")).sendKeys(a1);
    }
    public void enterHeight(String b1)
    {
        driver.findElement(By.name("cheightmeter")).sendKeys(b1);
    }
    public void enterWeight(String c1)
    {
        driver.findElement(By.name("ckg")).sendKeys(c1);
    }
    public void clickCalculateBtn()
    {
        driver.findElement(By.xpath("//input[@type='image']")).click();

    }
     public String getResult()
    {
        String  actual = driver.findElement(By.tagName("b")).getText().trim();
        return actual;
    }

    public String calculate1(String a1, String b1, String c1)
    {
        resetCalculator();
        enterAge(a1);
        enterHeight(b1);
        enterWeight(c1);
        clickCalculateBtn();
        String actual=getResult();
        return actual;


    }
}

