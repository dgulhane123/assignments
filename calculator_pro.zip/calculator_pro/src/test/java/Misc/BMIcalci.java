package Misc;

import Pages.CalculatorPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

//import java.util.List;

public class BMIcalci
    {
    WebDriver driver;
    CalculatorPage calci_pg;

    @BeforeMethod
    void intialize()
    {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        calci_pg=new CalculatorPage(driver);

    }

    @AfterMethod
    public void Close_driver()
    {
        driver.close();
    }



        @Test(priority = 1)
        void testcase1()
        {
            driver.findElement(By.className("rbmark")).click();
            Assert.assertEquals(calci_pg.calculate1("20","180","60"),"BMI = 18.5 kg/m2");
        }
        @Test(priority = 2)
        void testcase2()
        {
            driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[2]")).click();
            Assert.assertEquals(calci_pg.calculate1("35","160","55"),"BMI = 21.5 kg/m2");
        }
        @Test(priority = 3)
        void testcase3()
        {
            driver.findElement(By.className("rbmark")).click();
            Assert.assertEquals(calci_pg.calculate1("50","175","65"),"BMI = 21.2 kg/m2");

        }
        @Test(priority = 4)
        void testcase4()
        {
            driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[2]")).click();
            Assert.assertEquals(calci_pg.calculate1("45","150","52"),"BMI = 23.1 kg/m2");
        }
}


